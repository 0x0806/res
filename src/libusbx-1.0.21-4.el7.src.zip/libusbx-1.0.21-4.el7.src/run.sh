find . | tee -a ./src.list
