/*
 * Copyright (c) 2015-2018 Dmitry V. Levin <ldv@altlinux.org>
 * All rights reserved.
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#undef MPERS_PRINTER_NAME
#define MPERS_PRINTER_NAME(printer_name) printer_name

#include "native_printer_decls.h"
