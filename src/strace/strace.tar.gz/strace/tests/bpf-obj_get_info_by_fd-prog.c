#define CHECK_OBJ_PROG 1
#include "bpf-obj_get_info_by_fd.c"
