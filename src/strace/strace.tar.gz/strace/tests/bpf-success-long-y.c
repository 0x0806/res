#define INJECT_RETVAL ((long) 0xbadc0de1e55beefULL)
#define FD0_PATH "</dev/full>"
#include "bpf.c"
