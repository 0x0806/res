#define INJECT_RETVAL 42
#include "bpf-v.c"
