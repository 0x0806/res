#define XLAT_VERBOSE 1
#include "clone3.c"
