#define RETVAL_INJECTED 1
#define XLAT_VERBOSE 1
#include "clone3.c"
