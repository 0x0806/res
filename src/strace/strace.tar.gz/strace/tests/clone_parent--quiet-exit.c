#define QUIET_MSG 1
#include "clone_parent.c"
