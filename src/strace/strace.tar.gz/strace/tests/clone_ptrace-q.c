#define QUIET_ATTACH 1
#include "clone_ptrace.c"
