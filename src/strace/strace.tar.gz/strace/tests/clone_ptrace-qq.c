#define QUIET_ATTACH 1
#define QUIET_EXIT 1
#include "clone_ptrace.c"
