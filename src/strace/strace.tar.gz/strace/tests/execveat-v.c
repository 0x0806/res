/* This file is part of execveat-v strace test. */
#define VERBOSE 1
#include "execveat.c"
