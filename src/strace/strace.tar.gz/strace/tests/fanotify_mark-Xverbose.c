#define XLAT_VERBOSE 1
#include "fanotify_mark.c"
