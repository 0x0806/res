#define PIDNS_TRANSLATION
#include "fcntl64.c"
