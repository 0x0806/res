#define XLAT_RAW 1
#include "fstat.c"
