/* Check --no-abbrev decoding of getdents syscall.  */
#define VERBOSE 1
#include "getdents.c"
