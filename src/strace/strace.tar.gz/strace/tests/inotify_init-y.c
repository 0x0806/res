#define PRINT_PATHS
#include "inotify_init.c"
