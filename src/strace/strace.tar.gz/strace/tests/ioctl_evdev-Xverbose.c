#define XLAT_VERBOSE 1
#include "ioctl_evdev.c"
