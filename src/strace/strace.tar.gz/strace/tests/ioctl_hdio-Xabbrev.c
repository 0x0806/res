#define XLAT_ABBREV 1
#include "ioctl_hdio.c"
