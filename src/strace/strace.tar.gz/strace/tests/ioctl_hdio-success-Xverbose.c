#define XLAT_VERBOSE 1
#include "ioctl_hdio-success.c"
