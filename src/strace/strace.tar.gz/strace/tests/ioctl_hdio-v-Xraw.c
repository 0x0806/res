#define XLAT_RAW 1
#include "ioctl_hdio-v.c"
