#define XLAT_VERBOSE 1
#include "ioctl_hdio-v.c"
