#define VERBOSE 1
#include "ioctl_hdio.c"
