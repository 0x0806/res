#define VERBOSE 1
#include "ioctl_loop.c"
