#define XLAT_RAW 1
#include "ioctl_v4l2-success.c"
