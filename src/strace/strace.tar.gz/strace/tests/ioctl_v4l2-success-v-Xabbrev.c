#define XLAT_ABBREV 1
#include "ioctl_v4l2-success-v.c"
