#define VERBOSE 1
#include "ioctl_v4l2-success.c"
