#define XLAT_ABBREV 1
#include "ioctl_v4l2-v.c"
