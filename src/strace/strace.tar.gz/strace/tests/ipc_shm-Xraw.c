#define XLAT_RAW 1
#include "ipc_shm.c"
