#define XLAT_VERBOSE 1
#include "ipc_shm.c"
