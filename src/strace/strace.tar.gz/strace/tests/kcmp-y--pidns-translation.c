#define PIDNS_TRANSLATION
#include "kcmp-y.c"
