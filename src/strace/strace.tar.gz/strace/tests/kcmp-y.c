#define VERBOSE_FD 1

#include "kcmp.c"
