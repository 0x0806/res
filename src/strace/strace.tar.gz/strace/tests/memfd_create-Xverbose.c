#define XLAT_VERBOSE 1
#include "memfd_create.c"
