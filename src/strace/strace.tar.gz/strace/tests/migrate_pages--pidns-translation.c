#define PIDNS_TRANSLATION
#include "migrate_pages.c"
