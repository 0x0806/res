#define XLAT_RAW     1
#include "mmap.c"
