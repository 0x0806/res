#define XLAT_VERBOSE 1
#include "mount.c"
