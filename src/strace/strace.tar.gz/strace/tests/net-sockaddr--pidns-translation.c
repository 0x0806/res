#define PIDNS_TRANSLATION
#include "net-sockaddr.c"
