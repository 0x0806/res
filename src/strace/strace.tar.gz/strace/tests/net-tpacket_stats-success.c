#define INJECT_RETVAL 42
#include "net-tpacket_stats.c"
