#define XLAT_ABBREV 1
#include "openat2.c"
