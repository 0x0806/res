#define XLAT_VERBOSE 1
#include "openat2.c"
