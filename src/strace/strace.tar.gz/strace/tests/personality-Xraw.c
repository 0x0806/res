#define XLAT_RAW 1
#include "personality.c"
