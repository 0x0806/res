#define PIDFD_PATH "<anon_inode:[pidfd]>"
#define FD0_PATH "</dev/full>"
#include "pidfd_getfd.c"
