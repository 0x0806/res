#define XLAT_RAW 1
#include "printsignal.c"
