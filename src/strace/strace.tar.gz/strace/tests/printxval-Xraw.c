#define XLAT_RAW 1
#define XLAT_NAME(s_) s_##_raw
#include "printxval.c"
