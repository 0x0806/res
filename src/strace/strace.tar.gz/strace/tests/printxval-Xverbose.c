#define XLAT_VERBOSE 1
#define XLAT_NAME(s_) s_##_verbose
#include "printxval.c"
