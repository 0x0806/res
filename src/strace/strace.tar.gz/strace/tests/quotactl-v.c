/* This file is part of quotactl-v strace test. */
#define VERBOSE 1
#include "quotactl.c"
