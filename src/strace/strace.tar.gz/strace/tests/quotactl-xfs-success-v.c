#define INJECT_RETVAL 42
#include "quotactl-xfs-v.c"
