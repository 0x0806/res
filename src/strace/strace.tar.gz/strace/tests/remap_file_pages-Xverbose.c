#define XLAT_VERBOSE 1
#include "remap_file_pages.c"
