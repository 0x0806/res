#define PIDNS_TRANSLATION
#include "rt_tgsigqueueinfo.c"
