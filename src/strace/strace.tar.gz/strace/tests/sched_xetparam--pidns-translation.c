#define PIDNS_TRANSLATION
#include "sched_xetparam.c"
