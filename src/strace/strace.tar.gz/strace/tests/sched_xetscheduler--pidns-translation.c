#define PIDNS_TRANSLATION
#include "sched_xetscheduler.c"
