#define XLAT_RAW 1
#include "set_mempolicy.c"
