#define XLAT_VERBOSE 1
#include "set_mempolicy.c"
