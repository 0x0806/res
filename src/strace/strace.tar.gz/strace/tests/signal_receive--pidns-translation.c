#define PIDNS_TRANSLATION
#include "signal_receive.c"
