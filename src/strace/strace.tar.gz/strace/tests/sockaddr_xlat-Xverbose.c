#define XLAT_VERBOSE 1
#include "sockaddr_xlat.c"
