#define ATTACH_MODE 1
#include "stack-fcall.c"
