#define MANGLE
#include "stack-fcall-1.c"
