#define MANGLE
#include "stack-fcall-2.c"
