#define STRACE_XX 1
#include "strace-x.c"
