#define PIDNS_TRANSLATION
#include "tgkill.c"
