#define PIDNS_TRANSLATION
#include "tkill.c"
