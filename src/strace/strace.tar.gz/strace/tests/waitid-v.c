/* This file is part of waitid-v strace test. */
#define VERBOSE 1
#include "waitid.c"
