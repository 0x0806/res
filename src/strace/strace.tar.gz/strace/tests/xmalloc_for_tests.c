#define error_msg_and_die error_msg_and_fail
#include "xmalloc.c"
